# -*- coding: utf-8 -*-
"""
#==============================================================================
实现logistic回归分类算法，数据集为: dataset.csv

Created on 20190221
@version: V1.0
Python3.6 Code
#==============================================================================
"""
import numpy as np
import matplotlib.pyplot as plt

def loadDataSet():
    """
    加载数据集
    @: return: 返回数据列表及标签列表
    """
    dataMat = []
    labelMat = []
    fr = open('dataset.csv') #打开数据集
    for line in fr.readlines(): #遍历数据集的每一行
        lineArr = line.strip().split(',') #移除字符串首尾空白符之后进行切分
        dataMat.append([1.0, float(lineArr[0]), float(lineArr[1])]) #数据加入数据列表
        labelMat.append(int(lineArr[2])) #标签加入数据列表
    return dataMat, labelMat #返回数据列表及标签列表
    
def sigmoid(inX):
    """
    计算sigmoid函数
    @: param intX: 矩阵计算的结果(100x1)
    @: return: 计算结果
    """
    return 1.0 / (1 + np.exp(-inX))
        
def gradAscent(dataMat, labelMat):
    """
    梯度上升函数
    @: param dataMat: 数据集
    @: param labelMat: 标签集
    @： return: 权重参数矩阵(最佳回归系数)
    """
    dataMatrix = np.mat(dataMat)
    labelMat = np.mat(labelMat).transpose()
    m, n = np.shape(dataMatrix) #获取矩阵的行列数
    alpha = 0.001 #初始化步长参数
    maxCyc = 500 #初始化迭代次数
    weights = np.ones((n, 1)) #初始化矩阵的权重参数矩阵，均为1
    for k in range(maxCyc):
        h = sigmoid(dataMatrix * weights)
        error = labelMat-h #计算误差
        weights = weights + alpha * dataMatrix.transpose() * error #更新迭代参数
    return weights


def randomGradAscent(dataMat, labelMat):
    """
    随机梯度上升函数
    @: param dataMat: 数据集
    @: param labelMat: 标签集
    @： return: 权重参数矩阵(最佳回归系数)
    """
    dataMatrix = np.array(dataMat)
    m, n = np.shape(dataMatrix)
    alpha = 0.01 #初始化步长设置
    weights = np.ones(n) #初始化矩阵的权重参数矩阵，均为1
    for i in range(m):
        h = sigmoid(sum(dataMatrix[i]*weights))
        error = labelMat[i]-h #计算误差
        weights = weights + alpha * error * dataMatrix[i] #更新权重矩阵
    return weights


def randomGradAscent2(dataMat, labelMat):
    """
    改进的随机梯度上升算法
    @: param dataMat: 数据集
    @: param labelMat: 标签集
    @： return: 权重参数矩阵(最佳回归系数)
    """
    dataMatrix = np.array(dataMat)
    m, n = np.shape(dataMatrix)
    weights = np.ones(n) #初始化矩阵的权重参数矩阵，均为1
    numIter = 500 # 迭代次数
    for i in range(numIter):
        dataIndex = list(range(m)) #初始化index列表，这里要注意将range输出转换成list
        for j in list(range(m)): #遍历每一行数据，这里要注意将range输出转换成list
            alpha = 4/(1.0+i+j)+0.0001 #更新alpha值，缓解数据高频波动
            randIndex = int(np.random.uniform(0, len(dataIndex))) #随机生成序列号，从而减少随机性的波动
            h = sigmoid(sum(dataMatrix[randIndex]*weights)) #序列号对应的元素与权重矩阵相乘，求和后再求sigmoid
            error = labelMat[randIndex] - h #求误差，和之前一样的操作
            weights = weights + alpha * error * dataMatrix[randIndex] #更新权重矩阵
            del(dataIndex[randIndex]) #删除这次计算的数据
    return weights


def plotBestFit(weights):
    """
    绘图
    @:param weights: 系数矩阵
    @:output:分类结果图
    """
    dataMat, labelMat = loadDataSet()
    dataArr = np.array(dataMat)
    n = np.shape(dataArr)[0] #获取数组行数
    xcord1 = []; ycord1 = [] #初始化坐标
    xcord2 = []; ycord2 = []
    
    for i in range(n): #遍历每一行数据
        if int(labelMat[i]) == 1: #如果对应的类别标签对应数值1，就添加到xcord1，ycord1中
            xcord1.append(dataArr[i,1]); ycord1.append(dataArr[i,2])
        else: #如果对应的类别标签对应数值0，就添加到xcord2，ycord2中
            xcord2.append(dataArr[i,1]); ycord2.append(dataArr[i,2])

    fig = plt.figure()
    ax = fig.add_subplot(111) #添加subplot，三种数据都画在一张图上
    ax.scatter(xcord1, ycord1, s=30, c='red', marker='s') #1类用红色标识，marker='s'形状为正方形
    ax.scatter(xcord2, ycord2, s=30, c='green') #0类用绿色标识，弄认marker='o'为圆形
    x = np.arange(-3.0, 3.0, 0.1) #设置x取值，arange支持浮点型
    y = (-weights[0]-weights[1]*x)/weights[2] #配计算y的值
    ax.plot(x, y) #画拟合直线
    plt.xlabel('X1'); plt.ylabel('X2') #贴坐标表头
    plt.show() #显示结果    


if __name__ == '__main__':
    dataArr, labelMat = loadDataSet()
    # -------------梯度上升---------------
    weights = gradAscent(dataArr, labelMat)
    plotBestFit(weights.getA())  #.getA()用于将matrix转换成ndarray
    # -------------随机梯度上升-----------
    weights2 = np.mat(randomGradAscent(dataArr, labelMat)).transpose()
    print (weights2)
    plotBestFit(weights2.getA())
    # -------------改进随机梯度上升-----------
    weights3 = np.mat(randomGradAscent2(dataArr, labelMat)).transpose()
    print (weights3)
    plotBestFit(weights3.getA())
    
    
    