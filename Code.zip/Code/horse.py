# -*- coding: utf-8 -*-
"""
#==============================================================================
logistic回归分类算法的应用，数据集为: horse_colic_train.txt、horse_colic_test.txt

Created on 20190222
@version: V1.0
Python3.6 Code
#==============================================================================
"""
import numpy as np
import LogisticRegression  
from LogisticRegression import * #从LogisticRegression.py文件中导入函数

def classifyVector(inX, weights):
    """
    分类
    @：inX：为数据特征
    @：weights：模型参数
    """
    prob = LogisticRegression.sigmoid(sum(inX * weights))
    if prob > 0.5:  #假设为一平衡分类问题，分类阈值默认设置为0.5
        return 1.0
    else:
        return 0.0

def model_train():
    """
    模型训练
    @：trainWeights：返回训练得到的模型参数
    """
    frTrain = open('horse_colic_train.txt')
    trainingSet = []
    trainingLabels = []
    for line in frTrain.readlines():
        currLine = line.strip().split('\t')
        lineArr =[]
        for i in range(21):
            lineArr.append(float(currLine[i]))
        trainingSet.append(lineArr)
        trainingLabels.append(float(currLine[21]))
    trainWeights = LogisticRegression.randomGradAscent2(np.array(trainingSet), trainingLabels)
    return trainWeights

def model_test(trainWeights):
    """
    模型测试
    @：trainWeights：模型参数
    @：errorRate：模型测试错误率
    """
    frTest = open('horse_colic_test.txt')
    numTestVec = 0.0
    errorCount = 0
    for line in frTest.readlines():
        numTestVec += 1.0
        currLine = line.strip().split('\t')
        lineArr =[]
        for i in range(21):
            lineArr.append(float(currLine[i]))
        if int(classifyVector(np.array(lineArr), trainWeights))!= int(currLine[21]):
            errorCount += 1
    errorRate = (float(errorCount)/numTestVec)
    print ("测试的错误率为: %f" % errorRate)
      

def multiTest():
    """
    多次测试
    @：输出10次迭代后的评价错误率
    """
    errorSum = 0.0
    trainWeights = model_train() #模型训练，获取模型参数
    model_test(trainWeights)


if __name__ == '__main__':
    multiTest()